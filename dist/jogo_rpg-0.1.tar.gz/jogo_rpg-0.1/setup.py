

from setuptools import setup, find_packages

setup(
    name="jogo_rpg",  
    version="0.1",  
    packages=find_packages(), 
    install_requires=[],  
    description="Um jogo RPG simples em Python",
    author="Macauli Missouri",
    author_email="macaulimissouri0@gmail.com",
    url="https://github.com/macauli10/JogoDeRPG",  
)
