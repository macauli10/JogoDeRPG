def exibir_player():
    pass

def exibir_npc(npc):
    pass