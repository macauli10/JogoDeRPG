

from .player import player, level_up, reset_player, exibir_player
from .npc import criar_npc, gerar_npcs, reset_npc, exibir_npc, lista_npcs
from .batalha import iniciar_batalha

